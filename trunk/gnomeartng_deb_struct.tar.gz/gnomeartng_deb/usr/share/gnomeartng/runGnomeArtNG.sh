#!/bin/bash
exec mono ./GnomeArtNg.exe
